`timescale 1ns/1ps
module tb;
reg clk=0,rst_n=0,en=0;always #5 clk=~clk;
reg [6797-1:0] din=0;wire [264:0] dout;
reg [6797+1:0] stim[0:479-1];reg[264:0]expected[0:479-1];integer i;
nw_g9_or4s9 dut(.clk(clk),.rst_n(rst_n),.en(en),.din(din),.dout(dout));
initial begin
 $readmemh("stim.hex",stim);$readmemh("expect.hex",expected);$dumpfile("activity.vcd");$dumpvars(0,dut);
 for(i=0;i<479;i=i+1)begin
  @(negedge clk);{rst_n,en,din}=stim[i];@(posedge clk);#1;
  if(dout!==expected[i])begin $display("MISMATCH row=%0d got=%h expected=%h",i,dout,expected[i]);$fatal(1);end
 end
 @(negedge clk);#1;$display("FUNCTION_PASS transactions=%0d",479);$finish;
end
endmodule
