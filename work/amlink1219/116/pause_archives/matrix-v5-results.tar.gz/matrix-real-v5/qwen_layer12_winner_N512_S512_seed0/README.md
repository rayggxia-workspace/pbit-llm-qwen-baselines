# attention cycle execution

Latency: **322,762.50 ns** under declared timing assumptions.
Operations: 12337; cycle/event equivalence checked: True.

This is a shaped FFN/query execution, not a full-model quality or physical PPA result.

See `summary.json` for provenance, numeric gates, action counts and boundaries; `contracts.json` for clocks, resources and storage; `trace.json.gz` for the complete timeline.
