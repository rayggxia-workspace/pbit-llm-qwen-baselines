`timescale 1ns/1ps
module nt_g8_weighted_full(input wire clk,rst_n,en,input wire[6668:0]din,output wire[264:0]dout);nt_integrated #(.B(8),.M(8),.OR4(0),.CW(14),.SAT(0),.WEIGHTED(1),.SHARE(0),.GATE(0),.T(64))u(.*);endmodule
module nt_g8_weighted_share_ce(input wire clk,rst_n,en,input wire[6668:0]din,output wire[264:0]dout);nt_integrated #(.B(8),.M(8),.OR4(0),.CW(14),.SAT(0),.WEIGHTED(1),.SHARE(1),.GATE(0),.T(64))u(.*);endmodule
module nt_g8_weighted_share_icg(input wire clk,rst_n,en,input wire[6668:0]din,output wire[264:0]dout);nt_integrated #(.B(8),.M(8),.OR4(0),.CW(14),.SAT(0),.WEIGHTED(1),.SHARE(1),.GATE(1),.T(64))u(.*);endmodule
module nt_g8_or4s10_full(input wire clk,rst_n,en,input wire[6668:0]din,output wire[264:0]dout);nt_integrated #(.B(8),.M(8),.OR4(1),.CW(10),.SAT(1),.WEIGHTED(0),.SHARE(0),.GATE(0),.T(64))u(.*);endmodule
module nt_g8_or4s10_share_ce(input wire clk,rst_n,en,input wire[6668:0]din,output wire[264:0]dout);nt_integrated #(.B(8),.M(8),.OR4(1),.CW(10),.SAT(1),.WEIGHTED(0),.SHARE(1),.GATE(0),.T(64))u(.*);endmodule
module nt_g8_or4s10_share_icg(input wire clk,rst_n,en,input wire[6668:0]din,output wire[264:0]dout);nt_integrated #(.B(8),.M(8),.OR4(1),.CW(10),.SAT(1),.WEIGHTED(0),.SHARE(1),.GATE(1),.T(64))u(.*);endmodule
module nt_g8_or4s9_full(input wire clk,rst_n,en,input wire[6668:0]din,output wire[264:0]dout);nt_integrated #(.B(8),.M(8),.OR4(1),.CW(9),.SAT(1),.WEIGHTED(0),.SHARE(0),.GATE(0),.T(64))u(.*);endmodule
module nt_g8_or4s9_share_icg(input wire clk,rst_n,en,input wire[6668:0]din,output wire[264:0]dout);nt_integrated #(.B(8),.M(8),.OR4(1),.CW(9),.SAT(1),.WEIGHTED(0),.SHARE(1),.GATE(1),.T(64))u(.*);endmodule
