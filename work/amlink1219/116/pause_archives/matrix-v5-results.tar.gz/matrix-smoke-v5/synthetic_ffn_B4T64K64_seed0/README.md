# ffn cycle execution

Latency: **44,175.00 ns** under declared timing assumptions.
Operations: 1649; cycle/event equivalence checked: True.

This is a shaped FFN/query execution, not a full-model quality or physical PPA result.

See `summary.json` for provenance, numeric gates, action counts and boundaries; `contracts.json` for clocks, resources and storage; `trace.json.gz` for the complete timeline.
