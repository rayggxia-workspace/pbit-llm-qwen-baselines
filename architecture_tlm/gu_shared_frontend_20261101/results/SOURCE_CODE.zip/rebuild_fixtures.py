"""Rebuild36 frozen fixture files;requires Python>=3.10,stdlib only."""
from pathlib import Path
import hashlib,json,sys
import vectors
root=Path(__file__).resolve().parent
dest=Path(sys.argv[1]).resolve()
assert not dest.exists() or not any(dest.iterdir()), 'Choose an empty task-local directory'
dest.mkdir(parents=True,exist_ok=True);vectors.ROOT=dest
for case in json.loads((root/'CASES.json').read_text()):
 for seed in (17,503,1009):vectors.fixtures(case,seed)
hashes=json.loads((root/'FIXTURE_SHA256.json').read_text())
for n,h in hashes.items():assert hashlib.sha256((dest/n).read_bytes()).hexdigest()==h,n
print(json.dumps(dict(status='PASS',fixture_members_verified=len(hashes))))
