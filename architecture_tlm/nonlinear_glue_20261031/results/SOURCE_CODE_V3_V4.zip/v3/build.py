"""Generate a new immutable K64 conversion/AND characterization snapshot."""
from pathlib import Path
import hashlib,json,math,random,shutil

ROOT=Path(__file__).resolve().parent
SEEDS=(17,503,1009)
EXPONENTS=(3,4,5,6)

def save(p,x):
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes((json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def convert(g,u,b,sel):
 ag=min(255,round(abs(g)*2.**(13-b-EXPONENTS[sel])))
 au=(u&((1<<(b-1))-1))<<(9-b)
 field=g if b==8 else max(-128,min(127,round(g/2)))
 return ag,au,field,int(g<0),u>>(b-1)

def frame(rng,b,sel,index=None):
 limit=1<<(b-1)
 g=[rng.randrange(-limit,limit) for _ in range(64)]
 u=[rng.randrange(1<<b) for _ in range(64)]
 if index is not None:g=[(index*64+i)%(2*limit)-limit for i in range(64)]
 return g,u

def event(c,rng,g,u,sel,t,mode='grid'):
 b=c['bits'];di=0;co=0;z=0;sign=0;fields=0
 for i in range(64):
  ag,au,f,sg,su=convert(g[i],u[i],b,sel)
  fields|=(f&255)<<(i*8)
  if mode=='endpoints':
   rg=[0,ag,max(0,ag-1),255][i%4];ru=[0,au,max(0,au-1),255][(i+1)%4]
   q=[0,256,128,255][i%4];rs=[0,255,128,127][i%4]
  else:
   rg=(((t//8)%4)<<6)|rng.randrange(64)
   rs=(((t//4)%2)<<7)|rng.randrange(128)
   ru=((t%4)<<6)|rng.randrange(64)
   q=round(256/(1+math.exp(-f/8)))
  zz=int(rg<ag and rs<q and ru<au)
  z|=zz<<i;sign|=(sg^su)<<i
  if c['family']=='convert':
   di|=((g[i]&((1<<b)-1))|(u[i]<<b))<<(i*2*b)
   co|=(ag|(au<<8)|((f&255)<<16)|(sg<<24)|(su<<25))<<(i*26)
  elif c['family']=='and':
   # Distinct synthetic bit streams; no hidden PRNG in the synthesized DUT.
   aa=rng.getrandbits(1);bb=rng.getrandbits(1);cc=rng.getrandbits(1)
   di|=(aa<<i)|(bb<<(64+i))|(cc<<(128+i))|(sg<<(192+i))|(su<<(256+i))
   if aa&bb&cc:z|=1<<i
   else:z&=~(1<<i)
  else:
   word=(g[i]&((1<<b)-1))|(u[i]<<b)|(rg<<(2*b))|(rs<<(2*b+8))|(ru<<(2*b+16))|(q<<(2*b+24))
   di|=word<<(i*(2*b+33))
 if c['family']!='and':di|=sel<<(c['din_bits']-2)
 return di,co if c['family']=='convert' else z|(sign<<64)|((fields<<129) if c['family']=='core' else 0)

def fixtures(c,seed):
 rng=random.Random(seed);b=c['bits'];rows=[];expect=[];zr=0
 def add(di,value,en=1,rst=1):
  nonlocal zr
  if c['family']=='convert':out=value
  elif c['pipe']:
   if not rst:zr=0
   elif en:zr=value&((1<<64)-1)
   out=(value&~((1<<64)-1))|zr|((int(bool(en and rst)))<<128)
  else:out=value|(en<<128)
  rows.append(di|(en<<c['din_bits'])|(rst<<(c['din_bits']+1)));expect.append(out)
 g,u=[0]*64,[0]*64;di,val=event(c,rng,g,u,0,0)
 add(di,val,0,0);add(di,val,0,0)
 # Exhaustive signed g codes and all four scales, with explicit drain on changes.
 for sel in range(4):
  for j in range((1<<b)//64):
   g,u=frame(rng,b,sel,j);di,val=event(c,rng,g,u,sel,0,'endpoints')
   add(di,val,0);add(di,val);add(di,val,0)
 windows=[]
 start=len(rows)
 for _ in range(128):add(di,val,0)
 windows.append(dict(mode='idle',start_ns=10+10*start,end_ns=10+10*len(rows),operations=0,samples=0))
 for T,frames in ((32,16),(128,8)):
  start=len(rows)
  for fno in range(frames):
   sel=fno%4;g,u=frame(rng,b,sel);di,val=event(c,rng,g,u,sel,0)
   add(di,val,0)
   for t in range(T):
    di,val=event(c,rng,g,u,sel,t);add(di,val)
   add(di,val,0)
  windows.append(dict(mode='hold'+str(T),start_ns=10+10*start,end_ns=10+10*len(rows),operations=frames,samples=frames*T,active_cycles=T,cycles_per_frame=T+2))
 dst=ROOT/'fixtures'/c['name']/str(seed);dst.mkdir(parents=True,exist_ok=True)
 for name,words,width in [('stim.hex',rows,c['din_bits']+2),('expect.hex',expect,c['dout_bits'])]:
  (dst/name).write_bytes(('\n'.join(format(x,'0%dx'%((width+3)//4)) for x in words)+'\n').encode())
 save(dst/'WINDOWS.json',dict(transactions=len(rows),windows=windows,seed=seed,synthetic=True,
  description='Uniform signed g and sign+mag u codes; codes/scale held for T samples; Cartesian4x2x4 external thresholds; one load and one drain cycle. No distribution/quality claim.'))
 return len(rows)

def main():
 if (ROOT/'EXECUTION_MANIFEST.json').exists():raise RuntimeError('Frozen snapshot; do not rebuild')
 old=ROOT.parent/'accumulator_wrap_20261030';flow=ROOT/'flow';flow.mkdir(exist_ok=True)
 for n in ['upstream.py','common.tcl','library_conditions.tcl','dc.tcl','power_bulk.tcl','power_parse.py','power_vcd.py','vcd_alias_v2.py','constant_ports.py']:
  shutil.copyfile(old/'flow'/n,flow/n)
 comparator=ROOT.parents[2]/'rng-pbit8-issue95-20261027/architecture_tlm/random_service/pbit8_char/rtl/pbit_compare8.sv'
 # The peer checkout is read-only; copy the exact published two-comparator RTL.
 if sha(comparator)!='edf7df8dbdf28cccbfdb669e9e99e2813c238a87b49f4965942e41567a7e67ad':raise ValueError('Comparator source changed')
 shutil.copyfile(comparator,ROOT/'rtl/pbit_compare8.sv')
 cases=[]
 for family,bs,pipes in [('convert',(8,9),(0,)),('and',(8,),(0,1)),('core',(8,9),(0,1))]:
  for b in bs:
   for pipe in pipes:
    name=family+str(b)+('_reg' if pipe else '_comb')
    cases.append(dict(name=name,family=family,bits=b,pipe=pipe,din_bits=128*b+2 if family=='convert' else 320 if family=='and' else 64*(2*b+33)+2,dout_bits=1664 if family=='convert' else 129 if family=='and' else 641))
 tops=[];total=0
 for c in cases:
  top='ng_'+c['name'];c['top']=top
  module='ng_conversion64' if c['family']=='convert' else 'ng_and64' if c['family']=='and' else 'ng_core64'
  params=str(c['bits']) if c['family']=='convert' else str(c['pipe']) if c['family']=='and' else str(c['bits'])+','+str(c['pipe'])
  tops.append('module '+top+'(input wire clk,rst_n,en,input wire ['+str(c['din_bits']-1)+':0] din,output wire ['+str(c['dout_bits']-1)+':0] dout);\n'+module+' #('+params+') u(.*);\nendmodule\n')
  ns=[fixtures(c,s) for s in SEEDS];assert len(set(ns))==1;c['transactions']=ns[0];total+=sum(ns)
  bench='''`timescale 1ns/1ps
module tb;
reg clk=0,rst_n=0,en=0;always #5 clk=~clk;
reg [DI-1:0] din=0;wire [DO-1:0] dout;
reg [DI+1:0] stim[0:NUM-1];reg [DO-1:0] expected[0:NUM-1];integer i;
TOP dut(.clk(clk),.rst_n(rst_n),.en(en),.din(din),.dout(dout));
initial begin
 $readmemh("stim.hex",stim);$readmemh("expect.hex",expected);
 $dumpfile("activity.vcd");$dumpvars(0,dut);
 for(i=0;i<NUM;i=i+1)begin
  @(negedge clk);{rst_n,en,din}=stim[i];@(posedge clk);#1;
  if(dout!==expected[i])begin $display("MISMATCH row=%0d got=%h expected=%h",i,dout,expected[i]);$fatal(1);end
 end
 @(negedge clk);#1;$display("FUNCTION_PASS transactions=%0d",NUM);$finish;
end
endmodule
'''.replace('TOP',top).replace('NUM',str(ns[0])).replace('DI',str(c['din_bits'])).replace('DO',str(c['dout_bits']))
  dst=ROOT/'benches'/(c['name']+'.sv');dst.parent.mkdir(exist_ok=True);dst.write_bytes(bench.encode())
 (ROOT/'rtl/tops.sv').write_bytes(('\n'.join(tops)).encode());save(ROOT/'CASES.json',cases)
 save(ROOT/'CONFIG.json',dict(N=64,exponents=list(EXPONENTS),exponent_scope='four representative test exponents; not a model-calibrated catalog',PVT='SS1.08V125C',clock_MHz=100,load_pF=.001,area_factor=.81,seeds=list(SEEDS),source_head='d6bd32487b57f9573a74f906390d31b9108565ec',source_PR219='3a501411c64f5680862cf0eab0b1f82b70994c23',RTL_transactions=total,PT_windows=72,boundary='Core includes conversion,192comparators,64AND3,64sign XOR; sigma LUT,PRNG,resident code SRAM,scale selection,Wd,physical broadcast,CTS/SDF/SPEF excluded. Registered variants 64z+valid CE flops; sign held externally through drain.'))
 print(json.dumps(dict(cases=len(cases),transactions=total,PT_windows=72)))

if __name__=='__main__':main()
