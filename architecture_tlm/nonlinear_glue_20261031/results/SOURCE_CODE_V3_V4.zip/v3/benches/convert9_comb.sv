`timescale 1ns/1ps
module tb;
reg clk=0,rst_n=0,en=0;always #5 clk=~clk;
reg [1154-1:0] din=0;wire [1664-1:0] dout;
reg [1154+1:0] stim[0:1810-1];reg [1664-1:0] expected[0:1810-1];integer i;
ng_convert9_comb dut(.clk(clk),.rst_n(rst_n),.en(en),.din(din),.dout(dout));
initial begin
 $readmemh("stim.hex",stim);$readmemh("expect.hex",expected);
 $dumpfile("activity.vcd");$dumpvars(0,dut);
 for(i=0;i<1810;i=i+1)begin
  @(negedge clk);{rst_n,en,din}=stim[i];@(posedge clk);#1;
  if(dout!==expected[i])begin $display("MISMATCH row=%0d got=%h expected=%h",i,dout,expected[i]);$fatal(1);end
 end
 @(negedge clk);#1;$display("FUNCTION_PASS transactions=%0d",1810);$finish;
end
endmodule
