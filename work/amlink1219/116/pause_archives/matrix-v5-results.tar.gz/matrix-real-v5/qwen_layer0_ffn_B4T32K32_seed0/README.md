# ffn cycle execution

Latency: **165,725.00 ns** under declared timing assumptions.
Operations: 4725; cycle/event equivalence checked: True.

This is a shaped FFN/query execution, not a full-model quality or physical PPA result.

See `summary.json` for provenance, numeric gates, action counts and boundaries; `contracts.json` for clocks, resources and storage; `trace.json.gz` for the complete timeline.
