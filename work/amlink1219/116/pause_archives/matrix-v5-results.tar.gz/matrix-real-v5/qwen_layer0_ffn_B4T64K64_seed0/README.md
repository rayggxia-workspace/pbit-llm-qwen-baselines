# ffn cycle execution

Latency: **216,925.00 ns** under declared timing assumptions.
Operations: 8117; cycle/event equivalence checked: True.

This is a shaped FFN/query execution, not a full-model quality or physical PPA result.

See `summary.json` for provenance, numeric gates, action counts and boundaries; `contracts.json` for clocks, resources and storage; `trace.json.gz` for the complete timeline.
