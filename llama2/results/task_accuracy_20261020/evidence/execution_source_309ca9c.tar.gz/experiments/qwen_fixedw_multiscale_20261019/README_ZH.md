# 固定INT8权重、输入多尺度概率编码

2026-10-19，Issue46，负责人jieruiz。基线集成提交c1555ae；独立分支task/46-fixedw-multiscale。

本轮只改全部24个FFN的输入概率编码，Attention保留原BF16 SDPA。权重采用历史每64×64 symmetric INT8，同一解码矩阵用于所有方案，不再次归一化成权重随机概率。矩阵输入包括RMSNorm后的x，以及恢复g/u后准确连续FP32 SiLU(g)×u产生的z；二者分别编码、使用独立stage随机流。

## 编码与随机流

- dynamic64：原每token/64通道absmax，尺度maxabs×256/255，作为原范围算法的固定W对照。
- pot1/4/8：每token/64通道最大幅度的向上二次幂为顶档，后续档依次除4；每元素选择能容纳自己的最小可用档，最低档以下继续使用最低档。不按幅度搬移通道，不主动裁剪大值。
- 幅度阈值q=clip(round(abs(value)×256/S),0,255)，p=q/256；abs(value)>=S时恒1旁路。8位阈值外还需独立符号和端点语义，多档需要档号。
- 同64输入每拍共享同一自然IID均匀R8，跨档仍共享，不为每档另抽随机字。shared_counts通过联合区间计数准确抽样，保留共享相关性；不是lane独立二项，也不是Gaussian、分层或枚举。gate/up复用同一份x计数。
- 固定W准确空间/时间归约允许先恢复各lane的sign×S×C/T，再执行F.linear；与按档精确计数后恢复在实数算术上等价。实现为FP32数值参考，未证明某一有限位宽RTL逐bit一致。

mean为确定性编码控制，不是非线性随机网络整体输出的数学期望。w8_only为固定W8、FP32 FFN算术且无A编码的对照，含中间算术精度变化，不称单独纯权重量化损失。

T是每次x/z随机编码阶段的流长度，不是整层FFN或整token的总硬件周期；分块复用、两个阶段及访存仍需调度。为隔离输入编码作用，旧W8的tile量化步长原样保留，它不一定为二次幂。因此仅输入范围采用PoT，不代表所有尺度恢复都已成为移位；将权重量化步长也限定为PoT，需要另做精度验证。

## 预注册评测

先重新核验模型/tokenizer/WT2 train-test原文和token SHA，运行单测，复现未改BF16完整WT2（2048窗口/1024步长、299077计分目标、参考11.652735）。随后41项512-token前缀：w8_only一次；四种编码分别mean与T64/128/256各seed0/1/2。

检查实际速度之后，再提交22项预选完整WT2：w8_only一次；dynamic64/pot4/pot8的mean及T128/256各3seed。若某策略/长度的三seed前缀均值大于W8-only前缀的1.5倍，完整随机项写明skip而不假装得到全量PPL。选择和门槛在执行前冻结；本轮仍属探索，不能把同一测试文本选参数当独立最终泛化评估。

所有模型更换均无训练，attention对象保持原样。每次执行冻结准确Git SHA，输出与源码目录分开，记录配置/数据/结果SHA、种子、协议和环境。概率寄存器、指数/档号、多桶归约、SRAM带宽成本需后续硬件评估，本轮没有新PT/PPA或能效结论。

## 运行

`run_multiscale.py prepare`生成identity/suite/READY及原BF16参考；`worker --phase screen|full --index N`运行预定单项。模型与语料路径由命令显式给出，全部GPU任务通过run.sbatch提交，不能在登录节点执行评测。

2026-10-19补测：用户追问64次，接续Issue46/PR47。`prepare --prepare-suite t64`重新验证身份、原BF16完整参考和单测；`worker --phase t64 --index 0..8`运行dynamic64/pot4/pot8各3seed的完整WT2，不沿用前缀筛查门槛。kernel与数值算法不变，新执行快照和输出独立，不能覆盖首批e6f29b1的65项原件。suite.executed_phases明确区分这11项与首批65项；早先“64仅前缀”是补测前的状态。
