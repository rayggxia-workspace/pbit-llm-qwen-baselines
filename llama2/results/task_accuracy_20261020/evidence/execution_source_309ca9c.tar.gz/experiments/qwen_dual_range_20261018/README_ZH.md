# 独立范围缩放与双随机误差定位

Issue32，依赖Issue30 / PR31的安全公开源码。只改数值范围，不训练；全部24层FFN，Attention保留原BF16。自然IID输入共享64、权重逐连接独立，准确计数，不用OR或优化序列。

| 名字 | 输入范围 | 权重范围 |
|---|---|---|
| old | 训练校准得到的固定每64通道Sx/Sz | 原64×64 tile W8 |
| input | 每token、每64通道absmax | 同old |
| weight | 同old | 每输出行、每64输入范围 |
| both | 同input | 同weight |

原代码输入和权重本来就各有尺度。本实验定位范围利用率和分组粒度，不将旧实现误述为共用一个尺度。

动态A8以及严格R8权重均使用 `S=maxabs×256/255`，`q=round(256×abs(value)/S)`，`p=q/256`，另存符号。权重从相同旧W8解码值重编码，避免混入另一套BF16量化。每种范围有完全不采样的期望路径控制，用以分离新舍入和有限采样。局部审计另加row64_ideal，保持旧W8均值，连续pW仅用于数学定位，不能冒称严格8位电路。

准备作业核模型/分词器/语料与冻结文件SHA，运行单测，重新运行未修改BF16完整WT2（2048窗口、1024 stride、299077计分token），再捕获前128个train token中每层前16个MLP输入。逐投影计算确定性误差、共享64输入精确协方差和独立W新增方差。

37项替换配置均用同一个128-token测试前缀（127计分token）；这只是快速诊断PPL，不能称完整WT2 PPL。包括四范围T256各3seed、无采样期望各1项、old/both固定W各3seed、both的T64/128/1024各3seed，以及仅gate/up或仅down采样各3seed。加完整和前缀BF16共39输出。分支消融中未采样的投影保留相同编码的确定期望，不偷偷恢复另一套量化。

权重逐行范围元数据是旧tile范围的64倍；动态输入需要在线absmax及尺度恢复。这是数值定位，不代表免费硬件改进，也不直接继承旧PPA。

原始校准由现有授权服务器提供，沿用旧CALIBRATION_ARTIFACTS与SHA，不能单靠Git获得。权重、语料、激活和长结果不入Git；只发布代码、小型汇总和文件SHA索引。原执行快照不可覆盖，新的测试修复使用新提交与新快照。

128token改善后增加2048token确认（不是完整WT2）：old/both期望控制各1项，both双随机T128/256各3seed，另跑完整与前缀BF16参考，共10输出。该确认使用相同17c89c3执行源，在首轮数组结束后才运行；命令与依赖见work/jieruiz/32/SUBMISSION_CONFIRMATION.json。

结果汇总脚本`analyze_results.py`在执行源冻结后添加，只读分析，不修改数值内核。授权证据目录内需有submission32.json、raw/<execution_sha>/、可选raw/<execution_sha>_prefix2048/及collection32*.json。执行`python analyze_results.py --evidence-dir <本地授权证据目录> --checkout <正式checkout>`会重建qwen/results/dual_range_20261018/的小型汇总、中文报告和原件SHA索引。模型、原始校准和逐case长诊断仍需授权访问。

后处理复核修订：公开SUMMARY中的baseline不能把完整BF16与前缀BF16混成一组；现已单列references，并由test_summary_protocol.py验证。执行快照17c89c3保持不变，其旧summarize未用于本次结果。修订只影响本地/发布的汇总；数值worker、范围内核和所有服务器原件均未改。W8是来源权重，严格R8概率阈值另加符号，物理存储布局未定稿。
