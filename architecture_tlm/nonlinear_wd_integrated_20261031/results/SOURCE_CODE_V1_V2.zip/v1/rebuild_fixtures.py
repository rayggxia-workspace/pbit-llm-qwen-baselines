from pathlib import Path
import hashlib,json
import build
root=Path(__file__).resolve().parent
for c in json.loads((root/'CASES.json').read_text()):
 for seed in (17,503,1009):build.fixtures(c,seed)
manifest=json.loads((root/'EXECUTION_MANIFEST.json').read_text())
for n,h in manifest['files'].items():
 if n.startswith('fixtures/'):
  if hashlib.sha256((root/n).read_bytes()).hexdigest()!=h:raise ValueError(n)
print('All fixture SHA256 matched original execution bytes.')
