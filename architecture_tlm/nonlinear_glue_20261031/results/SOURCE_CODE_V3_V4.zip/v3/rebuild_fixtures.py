from pathlib import Path
import hashlib,json
import build
root=Path(__file__).resolve().parent
cases=json.loads((root/'CASES.json').read_text())
for c in cases:
 for seed in (17,503,1009):build.fixtures(c,seed)
manifest=json.loads((root/'EXECUTION_MANIFEST.json').read_text())
for name,expected in manifest['files'].items():
 if name.startswith('fixtures/'):
  if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:raise ValueError(name)
print('All72 fixture files regenerated and exact SHA256 matched.')
