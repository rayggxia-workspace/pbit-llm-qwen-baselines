"""Matched 8-bit comparator/full-LUT versus 32-way shared LUT snapshots."""
from pathlib import Path
import hashlib,importlib.util,json,re,shutil,zipfile
P=Path(__file__).resolve().parent
OLD=P.parent/'nonlinear_wd_integrated_20261031'
SEEDS=(17,503,1009)
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
 if (P/'EXECUTION_MANIFEST.json').exists():raise RuntimeError('Frozen snapshot; create a new version')
 for name in ('rtl','benches','flow'):(P/name).mkdir(exist_ok=True)
 for name in ('codecs.sv','compare.sv','sigmoid.sv','primitives.sv'):shutil.copyfile(OLD/'rtl'/name,P/'rtl'/name)
 for src in (OLD/'flow').iterdir():
  if src.is_file():shutil.copyfile(src,P/'flow'/src.name)
 base=(OLD/'execution_v2/integrated.sv').read_text()
 base=base.replace('module nw_integrated #','module ns_integrated #').replace('WEIGHTED=0)','WEIGHTED=0,SHARE=0,GATE=0)')
 base=base.replace('reg [4:0] accepted;reg done;', '''reg [4:0] accepted;reg done;
 reg [4:0] load_index;reg ready;
 always @(posedge clk)begin
  if(!rst_n||clear)begin load_index<=0;ready<=!SHARE;end
  else if(SHARE&&!ready)begin
   if(load_index==31)ready<=1;
   else load_index<=load_index+1'b1;
  end
 end''').replace('wire fire=en&&!done&&!clear;','wire fire=en&&ready&&!done&&!clear;')
 base=base.replace('wire[63:0] z,xsign;','''wire[63:0] z,xsign;
 wire[511:0] fields;
 wire[15:0] shared_q8;
 genvar s;
 generate if(SHARE)begin:shared_lookup
  for(s=0;s<2;s=s+1)begin:group32
   wire[8:0] q;
   pbit_sigmoid8_lut lut(.drive8(fields[(s*32+load_index)*8+:8]),.q9(q));
   assign shared_q8[s*8+:8]=q[7:0];
  end
 end else begin:unused_lookup
  assign shared_q8=16'd0;
 end endgenerate''')
 base=base.replace('  pbit_sigmoid8_lut lut(.drive8(field),.q9(q));','''  assign fields[n*8+:8]=field;
  if(SHARE)begin:cached_sigma
   reg[7:0] probability;
   wire write_word=rst_n&&!clear&&!ready&&(load_index==(n%32));
   if(GATE)begin:word_gate
    wire probability_clk;
    ns_icg gate(.clk(clk),.enable(write_word),.gclk(probability_clk));
    always @(posedge probability_clk)probability<=shared_q8[(n/32)*8+:8];
   end else begin:clock_enable
    always @(posedge clk)if(write_word)probability<=shared_q8[(n/32)*8+:8];
   end
   // Reuse the already-required g sign to distinguish q=0 from q=256.
   // The unsigned comparator itself is strictly eight bits.
   assign q={(!sg&&(probability==8'd0)),probability};
  end else begin:full_sigma
   pbit_sigmoid8_lut lut(.drive8(field),.q9(q));
  end''')
 (P/'rtl/integrated.sv').write_bytes(base.encode())
 (P/'rtl/icg.sv').write_bytes(b'''`timescale 1ns/1ps
module ns_icg(input wire clk,enable,output wire gclk);
`ifdef SYNTHESIS
 CKGTX8_9TSVT technology_gate(.CK(clk),.E(enable),.TE(1'b0),.Q(gclk));
`else
 reg held_enable;
 always @(*)if(!clk)held_enable=enable;
 assign gclk=clk&held_enable;
`endif
endmodule
''')
 spec=importlib.util.spec_from_file_location('old_vectors',OLD/'build.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);v.ROOT=P
 cases=[];tops=[];equivalence=[]
 zip_path=P.parents[3]/'project_archives/nonlinear_wd204_20261031/nwd204_v2_20261031.zip'
 with zipfile.ZipFile(zip_path) as z:
  for weighted in (1,0):
   backend='weighted' if weighted else 'or4s9'
   for kind,share,gate in [('full',0,0),('share_ce',1,0),('share_icg',1,1)]:
    name='g8_'+backend+'_'+kind;di=64*40+4096+13
    c=dict(name=name,top='ns_'+name,bits=8,or4=0 if weighted else 1,cw=13 if weighted else 9,sat=0 if weighted else 1,M=8,din_bits=di,dout_bits=265,weighted_sum=bool(weighted),shared=share,icg=gate,probability_register_bits=512 if share else 0,comparator_width=8,cycles_per_frame=66 if share else 34,family='shared32_sigmoid_integrated')
    ns=[]
    for seed in SEEDS:
     v.fixtures(c,seed);folder=P/'fixtures'/name/str(seed)
     old_rows=(folder/'stim.hex').read_text().splitlines();old_expect=(folder/'expect.hex').read_text().splitlines();w=json.loads((folder/'WINDOWS.json').read_text())
     source_name='g8_'+backend
     for filename,data in [('stim.hex',(folder/'stim.hex').read_bytes()),('expect.hex',(folder/'expect.hex').read_bytes())]:
      member='nwd204_v2_20261031/fixtures/'+source_name+'/'+str(seed)+'/'+filename
      assert z.read(member)==data,(name,seed,filename)
      equivalence.append(dict(case=name,seed=seed,member=member,sha256=hashlib.sha256(data).hexdigest()))
     rows=[];expect=[];index_map={0:0};active_start=None
     clear_bit=64*40+4096+12
     for i,(line,ex) in enumerate(zip(old_rows,old_expect)):
      value=int(line,16);rows.append(line);expect.append(ex)
      if share and value>>(di+1)&1 and value>>clear_bit&1:
       prep=value&~(1<<clear_bit)&~(1<<di)
       rows.extend([format(prep,'0%dx'%((di+5)//4))]*32);expect.extend(['0'*67]*32)
      index_map[i+1]=len(rows)
     for window in w['windows']:
      start=round((window['start_ns']-10)/10);end=round((window['end_ns']-10)/10)
      window.update(start_ns=10+10*index_map[start],end_ns=10+10*index_map[end])
      if window['mode']=='replay32':
       active_start=index_map[start];window['cycles_per_frame']=c['cycles_per_frame']
       window['phase']='whole frame:clear+optional32lookup+32sample+readout'
     if share:
      w['windows'].append(dict(mode='prepare_first',start_ns=10+10*(active_start+1),end_ns=10+10*(active_start+33),operations=1,samples=0,outputs=0,phase='first active frame lookup32,one write per lane'))
     start_sample=active_start+(33 if share else 1)
     w['windows'].append(dict(mode='sample_first',start_ns=10+10*start_sample,end_ns=10+10*(start_sample+32),operations=1,samples=32,outputs=8,phase='first active frame sampling only,excludes clear/readout'))
     w.update(transactions=len(rows),shared_LUT=bool(share),real_word_ICG=bool(gate),probability_register_bits=c['probability_register_bits'],contract='Same sampled events/oracle as frozen prior g8;shared variants insert32lookup cycles after each clear;no double buffer or hidden latency')
     (folder/'stim.hex').write_bytes(('\n'.join(rows)+'\n').encode());(folder/'expect.hex').write_bytes(('\n'.join(expect)+'\n').encode());save(folder/'WINDOWS.json',w);ns.append(len(rows))
    assert len(set(ns))==1;c['transactions']=ns[0];cases.append(c)
    tops.append('module '+c['top']+'(input wire clk,rst_n,en,input wire['+str(di-1)+':0]din,output wire[264:0]dout);ns_integrated #(.B(8),.M(8),.OR4('+str(c['or4'])+'),.CW('+str(c['cw'])+'),.SAT('+str(c['sat'])+'),.WEIGHTED('+str(weighted)+'),.SHARE('+str(share)+'),.GATE('+str(gate)+'))u(.*);endmodule\n')
    bench=(OLD/'benches/g8_or4s9.sv').read_text()
    bench=bench.replace('nw_g8_or4s9',c['top'])
    # Replace the exact prior transaction count, not any bus width.
    prior=json.loads((OLD/'CASES.json').read_text())[2]['transactions']
    bench=re.sub(r'\b'+str(prior)+r'\b',str(ns[0]),bench)
    (P/'benches'/(name+'.sv')).write_bytes(bench.encode())
 (P/'rtl/tops.sv').write_bytes(('`timescale 1ns/1ps\n'+''.join(tops)).encode());save(P/'CASES.json',cases)
 flow=(P/'flow/run_integrated.py').read_text().replace("ROOT/'rtl/integrated.sv'","ROOT/'rtl/icg.sv',ROOT/'rtl/integrated.sv'")
 flow=flow.replace("_config=U.config\nU.config=lambda top,db:_config(top,db).replace('set CV2_LOAD_PF {0.02}','set CV2_LOAD_PF {0.001}')",'''_config=U.config
def config(top,db):
 s=_config(top,db).replace('set CV2_LOAD_PF {0.02}','set CV2_LOAD_PF {0.001}')
 if top.endswith('share_icg'):
  s=s.replace('set CV2_GATE_MODE {0}','set CV2_GATE_MODE {2}')+'\\nset CV2_ICG_EN_PIN {E}\\nset CV2_ICG_TE_PIN {TE}\\n'
 return s
U.config=config''')
 flow=flow.replace("operation_definition='oneK64/M8 frame:1load+32samples+1readout;8signed dot outputs+shared exponent;weights resident'","operation_definition='oneK64/M8 frame:'+str(c['cycles_per_frame'])+'cycles;34full or66shared;prepare/sample first-frame diagnostics separate'")
 flow=flow.replace("boundary='Only named mapped microbenchmark; no artificial input/output flops for combinational cases. Integrated g/u code to Wd M8 includes64 LUT,192 comparators,AND,7plane counters/restore;no GU matrix,PRNG,SRAM,crossK/FP/CTS/SDF/SPEF.'","boundary='Already encodedg8/u8->full64 or2shared LUT;512probability bits in shared variants;192eight-bit comparators;AND;fixedWd M8;weighted orOR4s9;no GU,SRAM,PRNG,crossK/FP/CTS/SDF/SPEF. CE or64realwordICG as case states.'")
 (P/'flow/run_integrated.py').write_bytes(flow.encode());shutil.copyfile(OLD/'job.sh',P/'job.sh')
 save(P/'CONFIG.json',dict(date='2026-10-31',issue=204,source_base='b411aaac3abb5be3fa72274cf34ea51ad7c6385a',N=64,M=8,T=32,seeds=list(SEEDS),PVT='SS1.08V125C',clock_MHz=100,area_factor=.81,load_pF=.001,comparator_bits=8,shared_LUTs=2,sharing=32,probability_bits_per_lane=8,endpoint_policy='q8low plus existingg sign reconstructs q=256;all256x256compare outcomes identical',measurement='34cyclesfull;66cyclesshared(singlebank cold);no hidden load;no newsource ormemory cost;64ICGword gates retained onlyinICG case',PT_windows=sum(3*(4 if c['shared'] else 3) for c in cases),functional_transactions=sum(3*c['transactions'] for c in cases)))
 save(P/'FIXTURE_EQUIVALENCE.json',dict(source_archive=str(zip_path),source_sha256=sha(zip_path),members=equivalence,old_bytes_identical_before_insert=True))
 table={int(a,16):int(q) for a,q in re.findall(r"8'h([0-9a-fA-F]{2}):\s*q9=9'd(\d+)",(P/'rtl/sigmoid.sv').read_text())}
 assert len(table)==256
 for a,q in table.items():
  for r in range(256):assert (r<q)==(((a<128)and(q&255)==0)or(r<(q&255)))
 print(json.dumps(dict(cases=len(cases),RTL_transactions=sum(3*c['transactions'] for c in cases),endpoint_checks=65536,PT_windows=sum(3*(4 if c['shared'] else 3) for c in cases))))
if __name__=='__main__':main()
