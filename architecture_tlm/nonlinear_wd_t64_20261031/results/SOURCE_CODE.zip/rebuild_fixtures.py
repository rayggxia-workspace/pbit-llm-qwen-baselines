"""Rebuild T64 fixture bytes independently of historical checkout paths."""
from pathlib import Path
import hashlib,json,sys
import vectors as v
ROOT=Path(__file__).resolve().parent
P=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT
P.mkdir(parents=True,exist_ok=True);v.ROOT=P
for c in json.loads((ROOT/'CASES.json').read_text()):
 for seed in (17,503,1009):
  v.fixtures(c,seed);folder=P/'fixtures'/c['name']/str(seed)
  old_rows=(folder/'stim.hex').read_text().splitlines();old_expected=(folder/'expect.hex').read_text().splitlines();w=json.loads((folder/'WINDOWS.json').read_text())
  rows=[];expected=[];index_map={0:0};shared=c['shared'];icg=c['icg'];di=6669;clear_bit=6668
  for i,(line,ex) in enumerate(zip(old_rows,old_expected)):
   value=int(line,16);rows.append(line);expected.append(ex)
   if shared and value>>(di+1)&1 and value>>clear_bit&1:
    prep=value&~(1<<clear_bit)&~(1<<di);rows.extend([format(prep,'01668x')]*32);expected.extend(['0'*67]*32)
   index_map[i+1]=len(rows)
  active_start=None
  for window in w['windows']:
   start=round((window['start_ns']-10)/10);end=round((window['end_ns']-10)/10)
   window.update(start_ns=10+10*index_map[start],end_ns=10+10*index_map[end])
   if window['mode']=='replay64':active_start=index_map[start];window['cycles_per_frame']=c['cycles_per_frame']
  if shared:w['windows'].append(dict(mode='prepare_first',start_ns=10+10*(active_start+1),end_ns=10+10*(active_start+33),operations=1,samples=0,outputs=0))
  start_sample=active_start+(33 if shared else 1)
  w['windows'].append(dict(mode='sample_first',start_ns=10+10*start_sample,end_ns=10+10*(start_sample+64),operations=1,samples=64,outputs=8))
  w.update(transactions=len(rows),T=64,shared_LUT=bool(shared),real_word_ICG=bool(icg),probability_register_bits=c['probability_register_bits'],contract='Same g/u/W as frozenT32 power frames;64synthetic4x4x4 samples;shared adds32cold lookup cycles;no PRNG/model quality claim')
  (folder/'stim.hex').write_bytes(('\n'.join(rows)+'\n').encode());(folder/'expect.hex').write_bytes(('\n'.join(expected)+'\n').encode());v.save(folder/'WINDOWS.json',w)
manifest=json.loads((ROOT/'EXECUTION_MANIFEST.json').read_text())['files'];count=0
for name,h in manifest.items():
 if name.startswith('fixtures/'):
  assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h,name;count+=1
assert count==72
print(json.dumps(dict(fixture_files=count,manifest_match='PASS')))
