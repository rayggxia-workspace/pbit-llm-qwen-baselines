#!/bin/bash
source "$HOME/.bashrc"
set -eo pipefail
export PYTHONDONTWRITEBYTECODE=1
python3 -B flow/run_glue.py "$1" --case "$SLURM_ARRAY_TASK_ID" --out "results/${1}_${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}"
