"""Synthetic bit-true K64/M8 g/u->nonlinearity->fixed Wd snapshots."""
from pathlib import Path
import hashlib,json,math,random,shutil
ROOT=Path(__file__).resolve().parent
SEEDS=(17,503,1009);MASK64=(1<<64)-1;OR_MASK=0x1111111111111111
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rne_div(x,r):
 q,rem=divmod(x,1<<r);half=1<<(r-1)
 return q+int(rem>half or(rem==half and q&1))
def amp(g,b,sel):
 d=13-b-(3+sel);m=abs(g)
 return min(255,m<<d if d>=0 else rne_div(m,-d))
def code_vectors(seed):
 rng=random.Random(seed+11000);frames=[]
 for f in range(8):
  frames.append(dict(g=[rng.uniform(-16,16) for _ in range(64)],u=[rng.random() for _ in range(64)],us=[rng.getrandbits(1) for _ in range(64)],sel=f%4,eu=(-1,0,2,3)[f%4],ew=-7))
 return frames
def weight_matrix(seed,mode=None):
 rng=random.Random(seed+991)
 return [[(127 if mode=='positive' else -127 if mode=='negative' else rng.randrange(-127,128)) for n in range(64)] for m in range(8)]
def fixtures(c,seed):
 b=c['bits'];rng=random.Random(seed+55000);rows=[];expected=[];state=[[0]*7 for _ in range(8)];accepted=0;done=False;stats={}
 def add(frame,w,t,en=1,clear=0,rst=1,tag='functional'):
  nonlocal state,accepted,done
  S=2*b+24;di=0;z=0;xsign=0
  for n in range(64):
   gc=max(-(1<<(b-1)),min((1<<(b-1))-1,round(frame['g'][n]*(1<<(b-5)))))
   um=min((1<<(b-1))-1,round(frame['u'][n]*(1<<(b-1))));uc=um|(frame['us'][n]<<(b-1))
   ag=amp(gc,b,frame['sel']);au=um<<(9-b);field=gc if b==8 else max(-128,min(127,round(gc/2)))
   q=round(256/(1+math.exp(-field/8)))
   rg=((t//8)%4)*64+rng.randrange(64);rs=((t//4)%2)*128+rng.randrange(128);ru=(t%4)*64+rng.randrange(64)
   bit=int(rg<ag and rs<q and ru<au);z|=bit<<n;xsign|=(int(gc<0)^frame['us'][n])<<n
   v=(gc&((1<<b)-1))|(uc<<b)|(rg<<(2*b))|(rs<<(2*b+8))|(ru<<(2*b+16));di|=v<<(n*S)
  for m in range(8):
   for n in range(64):di|=(abs(w[m][n])|(int(w[m][n]<0)<<7))<<(64*S+8*(m*64+n))
  tail=64*S+4096;di|=frame['sel']<<tail;di|=(frame['eu']&31)<<(tail+2);di|=(frame['ew']&31)<<(tail+7);di|=clear<<(tail+12)
  if not rst or clear:state=[[0]*7 for _ in range(8)];accepted=0;done=False
  elif en and not done:
   for m in range(8):
    wm=w[m];negative=xsign^sum(int(x<0)<<i for i,x in enumerate(wm))
    for p in range(7):
     mask=sum(((abs(x)>>p)&1)<<i for i,x in enumerate(wm));pos=z&mask&~negative;neg=z&mask&negative
     if c['or4']:
      pos=(pos|(pos>>1)|(pos>>2)|(pos>>3))&OR_MASK;neg=(neg|(neg>>1)|(neg>>2)|(neg>>3))&OR_MASK
     delta=pos.bit_count()-neg.bit_count();v=state[m][p]+delta
     if c['sat']:
      clipped=max(-(1<<(c['cw']-1)),min((1<<(c['cw']-1))-1,v));stats[tag+'_saturations']=stats.get(tag+'_saturations',0)+int(v!=clipped);v=clipped
     else:
      if not -(1<<(c['cw']-1))<=v<(1<<(c['cw']-1)):raise ValueError('Safe counter width overflow')
     state[m][p]=v
   accepted+=1;done=accepted==32
   stats[tag+'_events']=stats.get(tag+'_events',0)+z.bit_count()
  readout=done and not clear;out=0
  if readout:
   for m in range(8):out|=(sum(v<<p for p,v in enumerate(state[m]))&0xffffffff)<<(m*32)
   exponent=3+frame['sel']+frame['eu']+frame['ew']-5;out|=(exponent&255)<<256;out|=1<<264
  rows.append(di|(en<<c['din_bits'])|(rst<<(c['din_bits']+1)));expected.append(out)
  return di
 zero=dict(g=[0.]*64,u=[0.]*64,us=[0]*64,sel=0,eu=0,ew=-7);w=weight_matrix(seed)
 add(zero,w,0,0,1,0);add(zero,w,0,0,1,0)
 for mode in ('positive','negative','mixed','zero'):
  f=dict(g=[15.875 if i%2==0 or mode!='mixed' else -16. for i in range(64)],u=[.999]*64,us=[0]*64,sel=0,eu=0,ew=-7)
  if mode=='zero':f=zero
  dw=weight_matrix(seed,mode);add(f,dw,0,0,1)
  for t in range(32):
   if t==11:add(f,dw,t,0,0)
   add(f,dw,t)
  add(f,dw,31,0)
 windows=[]
 # Resident W is installed outside measured windows; it never changes in replay.
 add(zero,w,0,0,1);start=len(rows)
 for _ in range(64):add(zero,w,0,0)
 windows.append(dict(mode='idle',start_ns=10+10*start,end_ns=10+10*len(rows),operations=0,samples=0))
 start=len(rows)
 for f in code_vectors(seed):
  add(f,w,0,0,1,tag='active')
  for t in range(32):add(f,w,t,tag='active')
  add(f,w,31,0,tag='active')
 windows.append(dict(mode='replay32',start_ns=10+10*start,end_ns=10+10*len(rows),operations=8,samples=256,outputs=64,cycles_per_frame=34))
 dst=ROOT/'fixtures'/c['name']/str(seed);dst.mkdir(parents=True,exist_ok=True)
 for name,values,width in [('stim.hex',rows,c['din_bits']+2),('expect.hex',expected,265)]:
  (dst/name).write_bytes(('\n'.join(format(x,'0%dx'%((width+3)//4)) for x in values)+'\n').encode())
 save(dst/'WINDOWS.json',dict(transactions=len(rows),windows=windows,seed=seed,stats=stats,synthetic=True,weights='random fixed sign+mag7 for all8 measured frames;preload outside window',contract='g/u codes held across32 samples;three Cartesian4x2x4 threshold streams;one load/one readout'))
 return len(rows)