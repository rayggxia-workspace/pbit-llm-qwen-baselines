`timescale 1ns/1ps
module ng_convert8_comb(input wire clk,rst_n,en,input wire [1025:0] din,output wire [1663:0] dout);
ng_conversion64 #(8) u(.*);
endmodule

module ng_convert9_comb(input wire clk,rst_n,en,input wire [1153:0] din,output wire [1663:0] dout);
ng_conversion64 #(9) u(.*);
endmodule

module ng_and8_comb(input wire clk,rst_n,en,input wire [319:0] din,output wire [128:0] dout);
ng_and64 #(0) u(.*);
endmodule

module ng_and8_reg(input wire clk,rst_n,en,input wire [319:0] din,output wire [128:0] dout);
ng_and64 #(1) u(.*);
endmodule

module ng_core8_comb(input wire clk,rst_n,en,input wire [3137:0] din,output wire [640:0] dout);
ng_core64 #(8,0) u(.*);
endmodule

module ng_core8_reg(input wire clk,rst_n,en,input wire [3137:0] din,output wire [640:0] dout);
ng_core64 #(8,1) u(.*);
endmodule

module ng_core9_comb(input wire clk,rst_n,en,input wire [3265:0] din,output wire [640:0] dout);
ng_core64 #(9,0) u(.*);
endmodule

module ng_core9_reg(input wire clk,rst_n,en,input wire [3265:0] din,output wire [640:0] dout);
ng_core64 #(9,1) u(.*);
endmodule
