`timescale 1ns/1ps
module nw_g8_exact(input wire clk,rst_n,en,input wire [6668:0] din,output wire[264:0]dout);nw_integrated #(.B(8),.M(8),.OR4(0),.CW(13),.SAT(0)) u(.*);endmodule
module nw_g8_or4safe(input wire clk,rst_n,en,input wire [6668:0] din,output wire[264:0]dout);nw_integrated #(.B(8),.M(8),.OR4(1),.CW(11),.SAT(0)) u(.*);endmodule
module nw_g8_or4s9(input wire clk,rst_n,en,input wire [6668:0] din,output wire[264:0]dout);nw_integrated #(.B(8),.M(8),.OR4(1),.CW(9),.SAT(1)) u(.*);endmodule
module nw_g9_exact(input wire clk,rst_n,en,input wire [6796:0] din,output wire[264:0]dout);nw_integrated #(.B(9),.M(8),.OR4(0),.CW(13),.SAT(0)) u(.*);endmodule
module nw_g9_or4safe(input wire clk,rst_n,en,input wire [6796:0] din,output wire[264:0]dout);nw_integrated #(.B(9),.M(8),.OR4(1),.CW(11),.SAT(0)) u(.*);endmodule
module nw_g9_or4s9(input wire clk,rst_n,en,input wire [6796:0] din,output wire[264:0]dout);nw_integrated #(.B(9),.M(8),.OR4(1),.CW(9),.SAT(1)) u(.*);endmodule
