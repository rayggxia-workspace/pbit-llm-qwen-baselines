"""Regenerate all54 fixture files and verify exact frozen bytes, no EDA."""
from pathlib import Path
import hashlib,json,sys
import legacy_vectors as v
ROOT=Path(__file__).resolve().parent
P=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT
P.mkdir(parents=True,exist_ok=True);v.ROOT=P
cases=json.loads((ROOT/'CASES.json').read_text())
for c in cases:
 for seed in (17,503,1009):
  v.fixtures(c,seed);folder=P/'fixtures'/c['name']/str(seed)
  old_rows=(folder/'stim.hex').read_text().splitlines();old_expect=(folder/'expect.hex').read_text().splitlines();w=json.loads((folder/'WINDOWS.json').read_text())
  di=c['din_bits'];share=c['shared'];gate=c['icg'];rows=[];expect=[];index_map={0:0};clear_bit=64*40+4096+12
  for i,(line,ex) in enumerate(zip(old_rows,old_expect)):
   value=int(line,16);rows.append(line);expect.append(ex)
   if share and value>>(di+1)&1 and value>>clear_bit&1:
    prep=value&~(1<<clear_bit)&~(1<<di)
    rows.extend([format(prep,'0%dx'%((di+5)//4))]*32);expect.extend(['0'*67]*32)
   index_map[i+1]=len(rows)
  for window in w['windows']:
   start=round((window['start_ns']-10)/10);end=round((window['end_ns']-10)/10)
   window.update(start_ns=10+10*index_map[start],end_ns=10+10*index_map[end])
   if window['mode']=='replay32':
    active_start=index_map[start];window['cycles_per_frame']=c['cycles_per_frame'];window['phase']='whole frame:clear+optional32lookup+32sample+readout'
  if share:w['windows'].append(dict(mode='prepare_first',start_ns=10+10*(active_start+1),end_ns=10+10*(active_start+33),operations=1,samples=0,outputs=0,phase='first active frame lookup32,one write per lane'))
  start_sample=active_start+(33 if share else 1)
  w['windows'].append(dict(mode='sample_first',start_ns=10+10*start_sample,end_ns=10+10*(start_sample+32),operations=1,samples=32,outputs=8,phase='first active frame sampling only,excludes clear/readout'))
  w.update(transactions=len(rows),shared_LUT=bool(share),real_word_ICG=bool(gate),probability_register_bits=c['probability_register_bits'],contract='Same sampled events/oracle as frozen prior g8;shared variants insert32lookup cycles after each clear;no double buffer or hidden latency')
  (folder/'stim.hex').write_bytes(('\n'.join(rows)+'\n').encode());(folder/'expect.hex').write_bytes(('\n'.join(expect)+'\n').encode());v.save(folder/'WINDOWS.json',w)
manifest=json.loads((ROOT/'EXECUTION_MANIFEST.json').read_text())['files'];count=0
for n,h in manifest.items():
 if n.startswith('fixtures/'):
  assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n;count+=1
print(json.dumps(dict(fixture_files=count,manifest_match='PASS')))
